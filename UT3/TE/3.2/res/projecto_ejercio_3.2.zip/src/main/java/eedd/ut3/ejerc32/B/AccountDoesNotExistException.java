package eedd.ut3.ejerc32.B;

public class AccountDoesNotExistException extends Exception {
	static final long serialVersionUID = 1L; 
}
