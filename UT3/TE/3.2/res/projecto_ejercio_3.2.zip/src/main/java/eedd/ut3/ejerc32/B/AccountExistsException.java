package eedd.ut3.ejerc32.B;

public class AccountExistsException extends Exception {
	static final long serialVersionUID = 1L; 
}
