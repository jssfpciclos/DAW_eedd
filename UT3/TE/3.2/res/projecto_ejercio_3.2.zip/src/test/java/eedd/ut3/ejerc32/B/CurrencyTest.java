package eedd.ut3.ejerc32.B;

import org.junit.jupiter.api.*;
import static org.junit.jupiter.api.Assertions.*;

public class CurrencyTest {
	Currency SEK, DKK, NOK, EUR;
	
	@BeforeEach
	public void setUp() {
		/* Setup currencies with exchange rates */
		SEK = new Currency("SEK", 0.15);
		DKK = new Currency("DKK", 0.20);
		EUR = new Currency("EUR", 1.5);
	}

	@Test
	@DisplayName("Test nombre de la moneda")
	public void testGetName() {
		/* Testar los siguientes:
		 * SEK = "SEK"
		 * DKK y EUR
		 * */

	}
	
	@Test
	@DisplayName("Test ratio por moneda")
	public void testGetRate() {
		/* Testar los siguientes:
		 * SEK ratio es 0.15
		 * DKK ratio es 0.20
		 * EUR ratio es 1.5
		 * */


	}
	
	@Test
	@DisplayName("Test asignar ratio moneda")
	public void testSetRate() {
		/* Testar los siguientes: */

		SEK.setRate(0.80);
		/* SEK ratio = 0.80 */

		EUR.setRate(0.001);
		/* SEK ratio = 0.001 */
	}
	
	@Test
	@DisplayName("Test universal valores monedas")
	public void testGlobalValue() {
		/* Testar el valor universal para las monedas con una cantidad de 10000, con un exactitud de 0.00
		 * SEK == 1500
		 * DKK == 2000
		 * EUR == 15000
		 * */


	}
	
	@Test
	@DisplayName("Test conversion entre monedas")
	public void testValueInThisCurrency() {
		/* Testar los siguientes, con un exactitud de 0.00
		 * 1000 EUR = 1000 SEK
		 * 7500 DKK = 1000 SEK
		 * */


	}

}