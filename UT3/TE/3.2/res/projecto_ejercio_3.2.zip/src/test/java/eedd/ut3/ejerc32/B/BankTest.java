package eedd.ut3.ejerc32.B;

import eedd.ut3.ejerc32.B.Bank;
import eedd.ut3.ejerc32.B.Currency;
import org.junit.jupiter.api.*;
import static org.junit.jupiter.api.Assertions.*;

public class BankTest {
	Currency SEK, DKK;
	Bank SweBank, Nordea, DanskeBank;
	
	@BeforeEach
	public void setUp() throws Exception {
		DKK = new Currency("DKK", 0.20);
		SEK = new Currency("SEK", 0.15);
		SweBank = new Bank("SweBank", SEK);
		Nordea = new Bank("Nordea", SEK);
		DanskeBank = new Bank("DanskeBank", DKK);
		SweBank.openAccount("Ulrika");
		SweBank.openAccount("Bob");
		Nordea.openAccount("Bob");
		DanskeBank.openAccount("Gertrud");
	}

	@Test
	public void testGetName() {
		fail("Escribe los test aquí");
	}

	@Test
	public void testGetCurrency() {
		fail("Escribe los test aquí");
	}

	@Test
	public void testOpenAccount() throws AccountExistsException, AccountDoesNotExistException {
		fail("Escribe los test aquí");
	}

	@Test
	public void testDeposit() throws AccountDoesNotExistException {
		fail("Escribe los test aquí");
	}

	@Test
	public void testWithdraw() throws AccountDoesNotExistException {
		fail("Escribe los test aquí");
	}
	
	@Test
	public void testGetBalance() throws AccountDoesNotExistException {
		fail("Escribe los test aquí");
	}
	
	@Test
	public void testTransfer() throws AccountDoesNotExistException {
		fail("Escribe los test aquí");
	}
	
	@Test
	public void testTimedPayment() throws AccountDoesNotExistException {
		fail("Escribe los test aquí");
	}
}
