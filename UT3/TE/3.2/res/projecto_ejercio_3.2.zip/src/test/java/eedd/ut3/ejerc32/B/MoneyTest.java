package eedd.ut3.ejerc32.B;

import org.junit.jupiter.api.*;

import static org.junit.jupiter.api.Assertions.*;

public class MoneyTest {
    Currency SEK, DKK, NOK, EUR;
    Money SEK100, EUR10, SEK200, EUR20, SEK0, EUR0, SEKn100;

    @BeforeEach
    public void setUp() {
        SEK = new Currency("SEK", 0.15);
        DKK = new Currency("DKK", 0.20);
        EUR = new Currency("EUR", 1.5);
        SEK100 = new Money(10000, SEK);
        EUR10 = new Money(1000, EUR);
        SEK200 = new Money(20000, SEK);
        EUR20 = new Money(2000, EUR);
        SEK0 = new Money(0, SEK);
        EUR0 = new Money(0, EUR);
        SEKn100 = new Money(-10000, SEK);
    }

    @Test
    public void testGetAmount() {
        /* Testar los siguientes:
            * - Cantidad de dinero en SEK100
            * - Cantidad de dinero en EUR10
            * - Cantidad de dinero en SEK200
            * - Cantidad de dinero en EUR20
        * */
    }

    @Test
    @DisplayName("Test moneda en los billetes es la correcta")
    public void testGetCurrency() {
        /* Testear que la 'currency' es la correcta. SEK es la moneda, pues SEK100 (billete) es de la moneda. Testear que corresponde con la misma instancia
            * - Moneda de SEK100
            * - Moneda de EUR10
            * - Moneda de SEK200
            * - Moneda de EUR20
            * - Moneda de SEK0
            * - Moneda de EUR0
            * - Moneda de SEKn100
        * */



        /* Testear que el nombre de la moneda es correcto para cada uno de los billetes.  "SEK" debe ser igual SEK.getCurrency().getName()"
           Realizar para las monedas:
           * SEK100, EUR10, SEK200, EUR20, SEKO, EUR0, SEKn100
         * */


    }

    @Test
    @DisplayName("Test toString billete es correcto")
    public void testToString() {
        // Testear que la representación textual de un billete es el correcto.  Ej_ "100,00 SEK" corresponde a SEK100"

    }

    @Test
    public void testGlobalValue() {
        assertEquals(SEK.universalValue(10000), SEK100.universalValue());
        assertTrue(EUR10.equals(SEK100));
    }

    @Test
    @DisplayName("Test equivalencias en dinero")
    public void testEqualsMoney() {
        /* Testear True/False que:
        * SEK0 = EURO
        * EUR10 = EUR20 (no)
        * SEK0 = EUR10 (no)
        * SEKn100 = EUR0 (no)
        * EUR10 = EUR10
        * EUR10 = SEK100
        * */


    }

    @Test
    @DisplayName("Test sumar dinero")
    public void testAdd() {
        /* Testar lo siguiente:
        * SEK0 + EUR0 == 0 SEK;
        * SEK100 + EUR10 == 20000 SEK
        * SEK200 + SEK200 == 40000 SEK
        * */


    }

    @Test
    @DisplayName("Test restar dinero")
    public void testSub() {
        /* Testar lo siguiente:
         * SEK0 - EUR0 == 0 SEK;
         * SEK100 - EUR10 == 0 SEK
         * SEK200 - SEK200 == 0 SEK
         * SEKn100 - SEKn100 == -20000 SEK
         * */

    }

    @Test
    @DisplayName("Test es Zero")
    public void testIsZero() {
        /* Testear True/False que:
         * SEK100 (no) es Zero
         * SEK0
         * ERU0
         * SEKn100 (no)
         * */


    }

    @Test
    @DisplayName("Test negar dinero")
    public void testNegate() {
        /* Testar lo siguiente:
         * !EUR0 == 0
         * !SEK100 == -10000
         * !SEKn100 == 10000
         * !SEK200 == -20000
         * */

    }

    @Test
    @DisplayName("Test comparar")
    public void testCompareTo() {
        /* Testar las siguientes comparacionesm con True/False que:
         * SEKn100 compareTo EUR20 < 0
         * EUR0 compareTo SEK0 == 0
         * */

    }
}
