package eedd.ut3.ejerc32.A;

import junit.framework.TestCase;
import org.junit.jupiter.api.*;

public class QuadrilateralTest {

    private Quadrilateral square1, square2, rectangle1, rectangle2, quad;

    @BeforeEach
    public void setUp() {
        square1 = new Quadrilateral(new Point(0, 0), new Point(0, 3), new Point(3, 3), new Point(3, 0));
        square2 = new Quadrilateral(new Point(0, 0), new Point(0, 5), new Point(5, 5), new Point(5, 0));
        rectangle1 = new Quadrilateral(new Point(0, 0), new Point(0, 4), new Point(6, 4), new Point(6, 0));
        rectangle2 = new Quadrilateral(new Point(0, 0), new Point(0, 5), new Point(8, 5), new Point(8, 0));
        quad = new Quadrilateral(new Point(0, 0), new Point(0, 3), new Point(7, 2), new Point(7, 0));
    }


    // Continuar la clase...

}